import './app.css';
import Logo from './../../media/logo.ico';


function App() {
  document.title = "Falcão Compra e Venda"

  return (

    <nav>
      <div className="navbar">
        <div className="logo-container">
          <a href="index.html"><img src={Logo} alt="Logo" style={{ width: '75px', height: '75px' }} /></a>
        </div>
        <div className="text-container">
          <h1>Falcão Compra e Venda</h1>
        </div>
        <div className="bars_ico">
          <i className="fas fa-bars fa-3x"></i>
        </div>
      </div>
    </nav>
  )
}
export default App
